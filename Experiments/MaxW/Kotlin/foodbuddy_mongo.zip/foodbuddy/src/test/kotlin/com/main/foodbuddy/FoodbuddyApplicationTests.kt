package com.main.foodbuddy

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FoodbuddyApplicationTests {

	@Test
	fun contextLoads() {
	}

}
